drop table record;


create table record(id int auto_increment primary key,url varchar(255) no
t null,metadata varchar(60000));